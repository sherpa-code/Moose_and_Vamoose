package game;

import javafx.fxml.FXMLLoader;

import java.io.IOException;

public class Travel extends Main {

//    static void travelSceneSetup() {
//
//        // Links travel pane to FXML file
//        try {
//            main.setTravelPane(FXMLLoader.load(Main.class.getResource("TravelScene.fxml")));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}